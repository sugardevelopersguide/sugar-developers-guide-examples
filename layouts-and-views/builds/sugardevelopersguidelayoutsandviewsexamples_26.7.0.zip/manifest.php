<?php
$manifest = array (
  'id' => 'SugarDevelopersGuideLayoutsAndViewsExamples',
  'name' => 'Sugar Developers Guide | Layouts And Views Examples',
  'description' => 'Installable examples for Sugar customizations.',
  'version' => '26.7.0',
  'author' => 'Sugar Developers Guide',
  'is_uninstallable' => true,
  'built_in_version' => '26.1.0',
  'published_date' => '2026-07-17 20:58:04',
  'type' => 'module',
  'remove_tables' => false,
  'acceptable_sugar_versions' => 
  array (
    'regex_matches' => 
    array (
      0 => '^26\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
    1 => 'ENT',
    2 => 'ULT',
  ),
);
$installdefs = array (
  'id' => 'SugarDevelopersGuideLayoutsAndViewsExamples',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Accounts/Ext/Dependencies/hide_panels_based_upon_record_type.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Dependencies/hide_panels_based_upon_record_type.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/modules/Accounts/clients/base/views/record/record.php',
      'to' => 'custom/modules/Accounts/clients/base/views/record/record.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/modules/Accounts/clients/base/views/record/record.js',
      'to' => 'custom/modules/Accounts/clients/base/views/record/record.js',
    ),
    3 => 
    array (
      'from' => '<basepath>/custom/modules/JobQueue/clients/base/layouts/kickoff/kickoff.php',
      'to' => 'custom/modules/JobQueue/clients/base/layouts/kickoff/kickoff.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/custom/modules/JobQueue/clients/base/menus/header/header.php',
      'to' => 'custom/modules/JobQueue/clients/base/menus/header/header.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/custom/modules/JobQueue/clients/base/views/kickoff-content/kickoff-content.hbs',
      'to' => 'custom/modules/JobQueue/clients/base/views/kickoff-content/kickoff-content.hbs',
    ),
    6 => 
    array (
      'from' => '<basepath>/custom/modules/JobQueue/clients/base/views/kickoff-content/kickoff-content.js',
      'to' => 'custom/modules/JobQueue/clients/base/views/kickoff-content/kickoff-content.js',
    ),
  ),
);
