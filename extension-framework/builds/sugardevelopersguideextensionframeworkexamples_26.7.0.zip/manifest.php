<?php
$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    'regex_matches' => 
    array (
      0 => '^26\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
    1 => 'ENT',
    2 => 'ULT',
  ),
  'author' => 'Sugar Developers Guide',
  'description' => 'Installable examples for Sugar customizations.',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'Sugar Developers Guide | Extension Framework Examples',
  'published_date' => '2026-07-17 20:54:15',
  'type' => 'module',
  'version' => '26.7.0',
  'id' => 'SugarDevelopersGuideExtensionFrameworkExamples',
  'built_in_version' => '26.1.0',
  'remove_tables' => false,
);
$installdefs = array (
  'id' => 'SugarDevelopersGuideExtensionFrameworkExamples',
  'custom_fields' => 
  array (
    0 => 
    array (
      'name' => 'custom_priority_c',
      'label' => 'LBL_CUSTOM_PRIORITY',
      'type' => 'enum',
      'ext1' => 'contact_priority_list',
      'default_value' => '',
      'require_option' => 0,
      'audited' => true,
      'module' => 'Contacts',
      'mass_update' => 0,
      'duplicate_merge' => 0,
      'reportable' => 1,
      'importable' => true,
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/Extension/modules/Contacts/Ext/Language/en_us.custom_priority.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/Extension/application/Ext/Language/en_us.contact_priority.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/application/Ext/Include/amaiza_Substack.php',
      'to' => 'custom/Extension/application/Ext/Include/amaiza_Substack.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/SchedulersJobs/Ext/LogicHooks/job_failure.php',
      'to' => 'custom/Extension/modules/SchedulersJobs/Ext/LogicHooks/job_failure.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/Vardefs/audit_core_field.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/audit_core_field.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Administration/Ext/Language/en_us.amaiza_Substack.php',
      'to' => 'custom/Extension/modules/Administration/Ext/Language/en_us.amaiza_Substack.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Administration/Ext/Administration/amaiza_Substack.php',
      'to' => 'custom/Extension/modules/Administration/Ext/Administration/amaiza_Substack.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/custom/modules/SchedulersJobs/LogicHooks/SchedulersJobsLogicHooks.php',
      'to' => 'custom/modules/SchedulersJobs/LogicHooks/SchedulersJobsLogicHooks.php',
    ),
  ),
);
