<?php

$app_list_strings['contact_priority_list'] = [
    'low' => 'Low',
    'medium' => 'Medium',
    'high' => 'High',
];
