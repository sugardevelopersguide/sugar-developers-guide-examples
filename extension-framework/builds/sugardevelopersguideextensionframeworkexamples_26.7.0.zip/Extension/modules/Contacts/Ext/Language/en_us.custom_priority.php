<?php

$mod_strings['LBL_CUSTOM_PRIORITY'] = 'Support Priority';
