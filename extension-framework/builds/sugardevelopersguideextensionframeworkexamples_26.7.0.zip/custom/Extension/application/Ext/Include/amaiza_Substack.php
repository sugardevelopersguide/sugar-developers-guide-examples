<?php

$beanList['amaiza_Substack'] = 'amaiza_Substack';
$beanFiles['amaiza_Substack'] = 'modules/amaiza_Substack/amaiza_Substack.php';
$modules_exempt_from_availability_check['amaiza_Substack'] = 'amaiza_Substack';
