<?php

// Safely toggle a core framework field property to track changes.
$dictionary['Contact']['fields']['phone_office']['audited'] = true;
