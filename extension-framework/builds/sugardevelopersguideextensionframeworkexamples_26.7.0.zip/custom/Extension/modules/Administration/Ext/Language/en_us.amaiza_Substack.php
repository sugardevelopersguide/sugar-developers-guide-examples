<?php

$mod_strings['LBL_AMAIZA_SUBSTACK_SECTION_HEADER'] = 'Amaiza Publishing Platform';
$mod_strings['LBL_AMAIZA_SUBSTACK_SECTION_DESCRIPTION'] = 'Example custom Administration section for publishing integrations.';
$mod_strings['LBL_AMAIZA_SUBSTACK_LAUNCHER_TITLE'] = 'Substack Core Dashboard';
$mod_strings['LBL_AMAIZA_SUBSTACK_LAUNCHER_DESC'] = 'Access internal system utilities and publish directly to the Substack pipeline.';
