<?php
$manifest = array (
  'id' => 'SugarDevelopersGuideVardefsExamples',
  'name' => 'Sugar Developers Guide | Vardefs Examples',
  'description' => 'Installable examples for Sugar customizations.',
  'version' => '26.7.0',
  'author' => 'Sugar Developers Guide',
  'is_uninstallable' => true,
  'built_in_version' => '26.1.0',
  'published_date' => '2026-07-17 20:58:04',
  'type' => 'module',
  'remove_tables' => false,
  'acceptable_sugar_versions' => 
  array (
    'regex_matches' => 
    array (
      0 => '^26\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
    1 => 'ENT',
    2 => 'ULT',
  ),
);
$installdefs = array (
  'id' => 'SugarDevelopersGuideVardefsExamples',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/application/Ext/Language/en_us.payment_status.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.payment_status.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/MyModule/Ext/Vardefs/sugarfield_mail_tracking_number.php',
      'to' => 'custom/Extension/modules/MyModule/Ext/Vardefs/sugarfield_mail_tracking_number.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/MyModule/Ext/Vardefs/mail_tracking_number.php',
      'to' => 'custom/Extension/modules/MyModule/Ext/Vardefs/mail_tracking_number.php',
    ),
  ),
);
